#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
toolchain=/data00/home/lejunyang/.local/share/osdk/rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu
export HOME="$root/target/qa/home"
export CARGO_HOME="$root/target/qa/cargo"
export RUSTUP_HOME="$root/target/qa/rustup"
export CARGO_TARGET_DIR="$root/target/qa/build"
export RUSTC="$toolchain/bin/rustc"
export RUSTDOC="$toolchain/bin/rustdoc"
export PATH="$toolchain/bin:/usr/bin:/bin"
unset GOPROXY GOPRIVATE GONOPROXY GOINSECURE OSDK_MANAGED_ENV OSDK_APPLIED_GOPROXY
export GOENV=off
exec "$toolchain/bin/cargo" "$@"
