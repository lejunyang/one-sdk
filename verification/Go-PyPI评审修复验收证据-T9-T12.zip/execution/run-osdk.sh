#!/bin/bash
set -euo pipefail
root=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
toolchain=/data00/home/lejunyang/.local/share/osdk/rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu
export HOME="$root/target/qa/home"
export CARGO_HOME="$root/target/qa/cargo"
export RUSTUP_HOME="$root/target/qa/rustup"
export CARGO_TARGET_DIR="$root/target/qa/build"
export RUSTC="$toolchain/bin/rustc"
export RUSTDOC="$toolchain/bin/rustdoc"
export PATH="$toolchain/bin:/usr/bin:/bin"
export OSDK_DATA_DIR="$root/target/qa/osdk/data"
export OSDK_CACHE_DIR="$root/target/qa/osdk/cache"
export OSDK_CONFIG_DIR="$root/target/qa/osdk/config"
export OSDK_STORE_DIR="$root/target/qa/osdk/store"
export OSDK_INSTALL_DIR="$root/target/qa/osdk/installs"
export OSDK_TRUSTED_CONFIG_PATHS="$root"
export RUSTUP_HOME="$root/target/qa/osdk/data/rustup"
export CARGO_HOME="$root/target/qa/osdk/cache/pkg/cargo"
export GOENV=off
unset GOPROXY GOPRIVATE GONOPROXY GOINSECURE PIP_INDEX_URL PIP_EXTRA_INDEX_URL UV_INDEX UV_INDEX_URL UV_DEFAULT_INDEX OSDK_MANAGED_ENV OSDK_APPLIED_GOPROXY
mkdir -p "$OSDK_INSTALL_DIR/python/3.12.0/bin" "$OSDK_CONFIG_DIR" "$OSDK_CACHE_DIR"
ln -sf /usr/bin/python3 "$OSDK_INSTALL_DIR/python/3.12.0/bin/python3"
touch "$OSDK_INSTALL_DIR/python/3.12.0/.osdk-complete"
exec /home/lejunyang/.local/bin/osdk "$@"
