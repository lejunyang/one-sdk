#!/bin/bash
set -euo pipefail
root=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
toolchain=/data00/home/lejunyang/.local/share/osdk/rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu
export HOME="$root/target/qa/home"
export CARGO_HOME="$root/target/qa/cargo"
export PATH="$root/target/qa/bin:$toolchain/bin:/usr/bin:/bin"
export OSDK_WINE_CARGO_HOME="$CARGO_HOME"
export OSDK_WINE_TARGET_DIR="$root/target/qa/wine-build"
export OSDK_WINE_CACHE_DIR="$root/target/qa/wine-cache"
export OSDK_TEST_TMPDIR="$root/target/qa/wine-tmp"
export GOENV=off
unset GOPROXY GOPRIVATE GONOPROXY GOINSECURE PIP_INDEX_URL PIP_EXTRA_INDEX_URL UV_INDEX UV_INDEX_URL UV_DEFAULT_INDEX OSDK_MANAGED_ENV OSDK_APPLIED_GOPROXY
exec ./scripts/windows-wine-tests.sh
